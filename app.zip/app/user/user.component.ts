import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { User } from '../model/user';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(private userService: UserService) { }

  users: any = [];
  editUser: User = new User();
  user: User;
  isEdit: boolean;
  firstname: string = "karthik";
  userId: string;
  

  ngOnInit() {
    this.user = new User();
    this.getAllUsers();
  }

  getAllUsers() {
    this.userService.getAllUsers().subscribe(resp => {
      this.users = resp;
      console.log(this.users);
    })
  }

  clear() {
    this.user = new User();
  }

  insert() {
    console.log(this.user);
    this.userService.createUser(this.user).subscribe(resp => {
      this.clear();
      this.getAllUsers();
    }
      );
  }

  update(editUser: any) {
    console.log(editUser);
    this.userService.updateUser(editUser).subscribe(resp => {
      let updatedUser: any = resp;
      this.clearEditing();
      this.users = this.users.filter(user => user.userId != editUser.userId);
      this.users.push(updatedUser);
    });
  }


  edit(user: User) {
    this.isEdit = true;
    this.editUser = Object.assign({}, user);
    console.log(this.editUser);
  }

  clearEditing() {
    this.isEdit = false;
    this.editUser = new User();
  }

  delete(userId: any) {
    console.log(userId);
    this.userService.deleteUser(userId).subscribe(
      resp => {
        this.users = this.users.filter(todo => todo.userId != userId);
        });
  }

  search() {
    this.userService.getUser(this.userId).subscribe(resp => {
      console.log(resp);
      let data: any = resp;
      if (resp != null) {
        this.users = [];
        this.users.push(data);
      } else {
        this.users = [];
      }
      console.log(this.users);
    },
      error => {
        this.users = [];
      }
    );
  }

}
