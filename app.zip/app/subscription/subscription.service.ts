import { Injectable } from '@angular/core';
import { Subscription } from './subscription';
import { Observable } from "rxjs";
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SubscriptionService {

  //private baseUrl = "http://localhost:8080";
  private baseUrl = "/jems2";

  constructor(private http: HttpClient) { }

  getAllSubscriptions(): Observable<any> {
    return this.http.get(this.baseUrl + "/subscription/getAll");
  }

  createSubscription(subscription: any): Observable<any> {
    return this.http
      .post(this.baseUrl + "/subscription/save", subscription);
  }

  updateSubscription(subscription: any): Observable<any> {
    return this.http
      .put(this.baseUrl + "/subscription/update", subscription);
  }

  deleteSubscription(id: string): Observable<any> {
    return this.http
      .delete(this.baseUrl + "/subscription/delete/" + id);
  }

  getSubscription(id: string) {
    return this.http
      .get(this.baseUrl + "/subscription/get/" + id);
  }
}
