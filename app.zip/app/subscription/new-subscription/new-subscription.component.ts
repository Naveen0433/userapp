import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource } from '@angular/material';
import { NewSubscriptionDialogComponent } from '../new-subscription-dialog/new-subscription-dialog.component';
import { UpdateSubscriptionDialogComponent } from '../update-subscription-dialog/update-subscription-dialog.component';
import { Subscription } from '../subscription';
import { SubscriptionService } from '../subscription.service';

@Component({
  selector: 'app-new-subscription',
  templateUrl: './new-subscription.component.html',
  styleUrls: ['./new-subscription.component.css']
})
export class NewSubscriptionComponent implements OnInit {

  subscriptionData: any = [];
  displayedColumns: string[] = ['delete','id', 'category', 'topic', 'agency'];
  dataSource: any;

  constructor(public dialog: MatDialog, private subscriptionService: SubscriptionService) { }

  create(): void {
    const dialogRef = this.dialog.open(NewSubscriptionDialogComponent, {
      width: '350px',
      data: { subscription: new Subscription() }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      console.log(result);
      if (result != undefined) {
        let subscription: any = result;
        this.subscriptionData.push(subscription);
        console.log(this.subscriptionData);
        this.dataSource = new MatTableDataSource(this.subscriptionData);
      }
    });
  }

  update(subscription: any,index:number) {
    const dialogRef = this.dialog.open(UpdateSubscriptionDialogComponent, {
      width: '350px',
      data: { subscription: subscription, oldSubscription: Object.assign({}, subscription) }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      console.log(result);
      if (result != undefined) {
        let subscription: any = result;
        this.subscriptionData[index] = subscription;
        console.log(this.subscriptionData);
        this.dataSource = new MatTableDataSource(this.subscriptionData);
      }
    });
  }

  ngOnInit() {
    this.subscriptionService.getAllSubscriptions().subscribe(
      resp => {
        this.subscriptionData = resp;
        this.dataSource = new MatTableDataSource(this.subscriptionData);
      }
    );

  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  delete(id: any) {
    console.log(id);
    this.subscriptionService.deleteSubscription(id).subscribe(() => {
      console.log("deleted");
      this.subscriptionData = this.subscriptionData.filter(subscription => subscription.subscriptionId != id);
      this.dataSource = new MatTableDataSource(this.subscriptionData);
    })

  }

}
