package jnet.jems2.service.impl;

import jnet.jems2.model.ObligationFilterRequest;
import jnet.jems2.service.ObligationFilterService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ObligationFilterServiceImpl implements ObligationFilterService {

    @Value("${obligationFilter.url}")
    private String filterUrl;

    private RestTemplate restTemplate = new RestTemplate();

    @Override
    public String getObligationFilters() {

        HttpHeaders headers = new HttpHeaders();
        headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.setContentType(MediaType.APPLICATION_JSON);

        ObligationFilterRequest request = new ObligationFilterRequest();
        request.setApi("1.0");
        request.setType("Filters");

//        ObligationFilterResponse response =
        String resp = restTemplate.postForObject(filterUrl, request, String.class);

//        return response.getFilters();
        return resp;
    }
}
