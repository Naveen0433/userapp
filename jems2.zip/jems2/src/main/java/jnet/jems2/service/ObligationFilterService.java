package jnet.jems2.service;

public interface ObligationFilterService {
    public String getObligationFilters();
}
