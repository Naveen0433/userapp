package jnet.jems2.service.impl;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import jnet.jems2.model.Subscription;
import jnet.jems2.model.SubscriptionSequence;
import jnet.jems2.repository.SubscriptionRepository;
import jnet.jems2.service.SubscriptionService;

@Service
public class SubscriptionServiceImpl implements SubscriptionService{
	
	@Autowired
	private SubscriptionRepository subscriptionRepository;

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public Subscription save(Subscription subscription) {
		subscription.setSubscriptionId(generateSequence(Subscription.SEQUENCE_NAME));
		return subscriptionRepository.insert(subscription);
	}

	@Override
	public Subscription update(Subscription subscription) {
		return subscriptionRepository.save(subscription);
	}

	@Override
	public void delete(Long subscriptionId) {
		subscriptionRepository.delete(subscriptionRepository.findById(subscriptionId).get());
	}

	@Override
	public List<Subscription> getAll() {
		return subscriptionRepository.findAll();
	}
	
	@SuppressWarnings("unused")
	private long generateSequence(String seqName) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(seqName));
		SubscriptionSequence counter = mongoTemplate.findAndModify(query, new Update().inc("sequence", 1),
				new FindAndModifyOptions().returnNew(true).upsert(true), SubscriptionSequence.class);
		return !Objects.isNull(counter) ? counter.getSequence() : 1;
	}

}
