package jnet.jems2.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import jnet.jems2.model.Subscription;

@Repository
public interface SubscriptionRepository extends MongoRepository<Subscription, Long>{

}
