package jnet.jems2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jems2Application {

	public static void main(String[] args) {
		SpringApplication.run(Jems2Application.class, args);
	}

}

