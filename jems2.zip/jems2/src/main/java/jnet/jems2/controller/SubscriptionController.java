package jnet.jems2.controller;

import java.util.List;
//import java.util.Map;
//import java.util.Set;

//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.multipart.MultipartFile;

import jnet.jems2.model.Subscription;

public interface SubscriptionController {
	public Subscription save(Subscription subscription);
	public Subscription update(Subscription subscription);
	public void delete(Long subscriptionId);
	public List<Subscription> getAll();
	//public String uploadFile(MultipartFile file);
	//public List<Map<String,String>> allObligationFilters();
	public String obligationFilter();
}
