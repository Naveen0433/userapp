package jnet.jems2.controller.impl;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import jnet.jems2.controller.SubscriptionController;
import jnet.jems2.model.Subscription;
import jnet.jems2.service.SubscriptionService;

@RestController
@RequestMapping(value="/subscription")
@CrossOrigin("*")
public class SubscriptionControllerImpl implements SubscriptionController{
	
	@Autowired
	private SubscriptionService subscriptionService;

	@Override
	@PostMapping(value="/save")
	public Subscription save(@RequestBody Subscription subscription) {
		return subscriptionService.save(subscription);
	}

	@Override
	@PutMapping(value="/update")
	public Subscription update(@RequestBody Subscription subscription) {
		return subscriptionService.update(subscription);
	}

	@Override
	@DeleteMapping(value="/delete/{subscriptionId}")
	public void delete(@PathVariable Long subscriptionId) {
		subscriptionService.delete(subscriptionId);
	}

	@Override
	@GetMapping(value="/getAll")
	public List<Subscription> getAll() {
		return subscriptionService.getAll();
	}
	
	@PostMapping(value="/saveFile") 
	public String uploadFile(@RequestParam MultipartFile file) {

	    try {
	        return "sucess";
	    } catch (Exception e) {
	        return "fail";
	    }
	}

}
