package jnet.jems2.model;

import java.util.List;

public class ObligationFilterResponse {

    public List<String> filters;

    public List<String> getFilters() {
        return filters;
    }

    public void setFilters(List<String> filters) {
        this.filters = filters;
    }
}
