package jnet.jems2.model;

import java.util.List;
import java.util.Map;

import org.bson.types.Binary;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.web.multipart.MultipartFile;

@Document(collection="subscription")
public class Subscription {
	
	@Transient
    public static final String SEQUENCE_NAME = "subscription_sequence";
	
	@Id
	private Long subscriptionId;
	private String userOrg;
	private String category;
	private String topic;
	private String filter;
	//private Binary xmlFile;
	//private org.bson.Document document;
	private List<Map<String,String>> obligationFilter;

	
	public Long getSubscriptionId() {
		return subscriptionId;
	}
	public void setSubscriptionId(Long subscriptionId) {
		this.subscriptionId = subscriptionId;
	}
	public String getUserOrg() {
		return userOrg;
	}
	public void setUserOrg(String userOrg) {
		this.userOrg = userOrg;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getFilter() {
		return filter;
	}
	public void setFilter(String filter) {
		this.filter = filter;
	}
	public List<Map<String, String>> getObligationFilter() {
		return obligationFilter;
	}
	public void setObligationFilter(List<Map<String, String>> obligationFilter) {
		this.obligationFilter = obligationFilter;
	}
	
	
	
	
	
	
	
}
