import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(private userService: UserService) { }

  users: any = [];

  user: any = {
    firstName: '',
    lastName: '',
    userName:''
  }

  ngOnInit() {
    this.getAllUsers();
  }

  getAllUsers() {
    this.userService.getAllUsers().subscribe(resp => {
      this.users = resp;
    })
  }

  clear() {
    this.user.firstName = '';
    this.user.lastName = '';
    this.user.userName = '';
  }

  insert() {
    console.log(this.user);
    this.userService.createUser(this.user).subscribe(resp => {
      this.clear();
      this.getAllUsers();
    }
      );
  }

}
