import { Injectable } from '@angular/core';
import { Observable } from "rxjs";
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseUrl = "http://localhost:8080";

  constructor(private http: HttpClient) { }

  getAllUsers(): Observable<any> {
    return this.http.get(this.baseUrl + "/user/getAll");
  }

  createUser(user: any): Observable<any> {
    return this.http
      .post(this.baseUrl + "/user/create", user);
  }

  updateUser(user: any): Observable<any> {
    return this.http
      .put(this.baseUrl + "/user/update" , user);
  }

  deleteUser(id: string): Observable<any> {
    return this.http
      .delete(this.baseUrl + "/user/get/" + id);
  }

  getUser() {

  }

}
