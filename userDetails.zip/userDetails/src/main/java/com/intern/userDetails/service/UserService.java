package com.intern.userDetails.service;

import java.util.List;

import com.intern.userDetails.model.User;

public interface UserService {

	public User create(User user);
	public User update(User user);
	public void delete(Long userId);
	public User getById(Long userId);
	public List<User> getAllUsers();
	
}
