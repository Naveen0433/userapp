package com.intern.userDetails.service.impl;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.intern.userDetails.model.DatabaseSequence;
import com.intern.userDetails.model.User;
import com.intern.userDetails.repository.UserRepository;
import com.intern.userDetails.service.UserService;


@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired 
	private MongoOperations mongoOperations;

	@Override
	public User create(User user) {
		user.setUserId(this.generateSequence(User.SEQUENCE_NAME));
		return userRepository.insert(user);
	}

	@Override
	public User update(User user) {
		User dbUser=userRepository.findById(user.getUserId()).get();
		dbUser.setFirstName(user.getFirstName());
		dbUser.setLastName(user.getLastName());
		userRepository.save(dbUser);
		return dbUser;
	}

	@Override
	public void delete(Long userId) {
		userRepository.deleteById(userId);
	}

	@Override
	public User getById(Long userId) {
		return userRepository.findById(userId).get();
	}

	@Override
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}
	
	public long generateSequence(String seqName) {
		
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(seqName));
		
	    DatabaseSequence counter = mongoOperations.findAndModify(query,
	      new Update().inc("seq",1), new FindAndModifyOptions().returnNew(true).upsert(true),
	      DatabaseSequence.class);
	    return !Objects.isNull(counter) ? counter.getSeq() : 1;
	}

}
