package com.intern.userDetails.controller;

import java.util.List;

import com.intern.userDetails.model.User;

public interface UserController {
	
	public User create(User user);
	public User update(User user);
	public void delete(String userId);
	public User getById(String userId);
	public List<User> getAllUsers();
	

}
