package com.intern.userDetails.controller.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.intern.userDetails.controller.UserController;
import com.intern.userDetails.model.User;
import com.intern.userDetails.service.UserService;


@RestController
@RequestMapping(value="/user")
@CrossOrigin("*")
public class UserControllerImpl implements UserController{
	
	@Autowired
	private UserService userService;

	@Override
	@PostMapping(value = "/create")
	public User create(@RequestBody User user) {
		return userService.create(user);
	}

	@Override
	@PutMapping(value = "/update")
	public User update(@RequestBody User user) {
		return userService.update(user);
	}

	@Override
	@DeleteMapping(value="/delete/{userId}")
	@CrossOrigin("*")
	public void delete(@PathVariable String userId) {
		userService.delete(Long.parseLong(userId));
	}

	@Override
	@GetMapping(value = "/get/{userId}")
	public User getById(@PathVariable String userId) {
		return userService.getById(Long.parseLong(userId));
	}

	@Override
	@GetMapping(value="/getAll")
	public List<User> getAllUsers() {
		return userService.getAllUsers();
	}

}
