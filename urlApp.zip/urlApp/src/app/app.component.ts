import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name: string;
  expandedItems: any =[];
  headerData: any = [];
  testData: any

  constructor() {
    this.name = 'Angular2';
    this.testData = [
      {
        name: 'Menu1',
        urls: [
          { name: "devUrl", url: "http://www.google.com" },
          { name: "sitUrl", url: "http://www.google.com" },
          { name: "uatUrl", url: "http://www.google.com" },
          { name: "prodUrl", url: "http://www.google.com" }
        ]
      },
      {
        name: 'Menu2',
        urls: [
          { name: "devUrl", url: "http://www.google.com" },
          { name: "sitUrl", url: "http://www.google.com" },
          { name: "uatUrl", url: "http://www.google.com" },
          { name: "prodUrl", url: "http://www.google.com" }
        ]
      }
    ];
  }

  toggleComment(item: number) {
    console.log(item);
    var exists = false;
    console.log(this.expandedItems);
    this.expandedItems.forEach(x => {
      if (x.name == this.testData[item].name) exists = true;
    });
    if (exists) {
      this.expandedItems.pop(this.testData[item]);
    }
    else {
      this.expandedItems.push(this.testData[item]);
    }
      console.log(this.expandedItems);
  }

}
