import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-life-cycle-hook-child',
  templateUrl: './life-cycle-hook-child.component.html',
  styleUrls: ['./life-cycle-hook-child.component.css']
})
export class LifeCycleHookChildComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
