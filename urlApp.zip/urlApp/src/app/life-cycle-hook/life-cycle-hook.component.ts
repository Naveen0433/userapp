import { Component, OnInit, OnChanges } from '@angular/core';

@Component({
  selector: 'app-life-cycle-hook',
  templateUrl: './life-cycle-hook.component.html',
  styleUrls: ['./life-cycle-hook.component.css']
})
export class LifeCycleHookComponent implements OnInit,OnChanges {

  constructor() { }

  ngOnInit() {
    console.log("Component on int");
  }
  
  ngOnChanges() {
    console.log("On Changesd called")
  }
}
