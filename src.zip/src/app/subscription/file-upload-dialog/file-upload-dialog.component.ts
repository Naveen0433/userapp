import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-file-upload-dialog',
  templateUrl: './file-upload-dialog.component.html',
  styleUrls: ['./file-upload-dialog.component.css']
})
export class FileUploadDialogComponent implements OnInit {


  percentDone: number;
  uploadSuccess: boolean;
  uploadedFile:File;

constructor(
    public dialogRef: MatDialogRef<FileUploadDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }

ngOnInit() {
  }


  cancel() {
    this.dialogRef.close();
  }

 
   uploadAndProgressSingle(file: File){
   console.log(file);
    this.uploadedFile=file;
  }

  create(){
     this.dialogRef.close(this.uploadedFile);
  }

  
  

}
