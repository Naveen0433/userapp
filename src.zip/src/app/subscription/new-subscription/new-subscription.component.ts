import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource,MatSort,MatPaginator } from '@angular/material';
import { NewSubscriptionDialogComponent } from '../new-subscription-dialog/new-subscription-dialog.component';
import { UpdateSubscriptionDialogComponent } from '../update-subscription-dialog/update-subscription-dialog.component';
import {ConfirmDialogComponent} from '../confirm-dialog/confirm-dialog.component';
import { Subscription } from '../subscription';
import { SubscriptionService } from '../subscription.service';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-new-subscription',
  templateUrl: './new-subscription.component.html',
  styleUrls: ['./new-subscription.component.css']
})
export class NewSubscriptionComponent implements OnInit {

  subscriptionData: any = [];
  displayedColumns: string[] = ['delete','subscriptionId', 'category', 'topic', 'userOrg','filter','obligationFilter'];
  dataSource: any;
  deleteId:any;
  @ViewChild(MatSort) sort:MatSort;
  @ViewChild(MatPaginator) paginator:MatPaginator;
  isAuthorized:boolean;
  filters:any;

  constructor(public dialog: MatDialog, private subscriptionService: SubscriptionService) { }

  ngOnInit() {

  /*
  let data={"Filters":["remove-fb1","remove-sid","remove-ssn","remove-otn"]};
  this.filters=data['Filters'];
  */

  
   this.subscriptionService.getAllObligationFilters().subscribe(data=>{
    this.filters=data["filters"];
    });
    
    
    this.subscriptionService.getAllSubscriptions().subscribe(
      resp => {
        this.subscriptionData = resp;
        this.subscriptionData.forEach(subData=>{
        if(subData!=null&&subData.obligationFilter!=null){
         this.prepareObligationFiler(subData);
        }
        });
        console.log(this.subscriptionData);
        this.dataSource = new MatTableDataSource(this.subscriptionData);
        this.dataSource.sort=this.sort;
         this.dataSource.paginator=this.paginator;
      }
    );

  }

  create(): void {
  if (!this.dialog.openDialogs || !this.dialog.openDialogs.length) {
    const dialogRef = this.dialog.open(NewSubscriptionDialogComponent, {
    width:'490px',
    panelClass: 'myapp-no-padding-dialog',
      data: { subscription: new Subscription(),obligationFilterList:this.filters }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      console.log(result);
      if (result != undefined) {
        let subscription: any = result;  
        this.prepareObligationFiler(subscription);
        this.subscriptionData.push(subscription);
        console.log(this.subscriptionData);
        this.dataSource = new MatTableDataSource(this.subscriptionData);
        this.dataSource.sort=this.sort;
         this.dataSource.paginator=this.paginator;
      }
    });
    }
  }

  update(subscription: any,index:number) {
    if (!this.dialog.openDialogs || !this.dialog.openDialogs.length) {
  let obligationFilterList:any=[];
  if(this.isAuthorized){
  const dialogRef = this.dialog.open(UpdateSubscriptionDialogComponent, {
      width: '490px',
      panelClass: 'myapp-no-padding-dialog',
      data: { subscription: subscription, oldSubscription: Object.assign({}, subscription),obligationFilterList:this.filters }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      console.log(result);
      if (result != undefined && result!=null) {
        let subscription: any = result;
        this.prepareObligationFiler(subscription);
        this.subscriptionData[index] = subscription;
        console.log(this.subscriptionData);
        this.dataSource = new MatTableDataSource(this.subscriptionData);
        this.dataSource.sort=this.sort;
         this.dataSource.paginator=this.paginator;
      }
    });
    }
    }
  }

  

  prepareObligationFiler(subData:any){
  console.log(subData);
  let obligationFilterFilesAsString="";
     for(let i:number=0;i<subData.obligationFilter.length;i++){
            if(i==0){
              obligationFilterFilesAsString+=""+subData.obligationFilter[i];
            }else{
              obligationFilterFilesAsString+=","+subData.obligationFilter[i];
            }
            subData["obligationFilterFilesAsString"]=obligationFilterFilesAsString;
          }
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

 delete(id: any){
 this.deleteId=id;
  const dialogRef = this.dialog.open(ConfirmDialogComponent, {
    width:'400px',
      data: { id: id }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      if (result != undefined) {
         this.subscriptionService.deleteSubscription(this.deleteId).subscribe(() => {
      this.subscriptionData = this.subscriptionData.filter(subscription => subscription.subscriptionId != this.deleteId);
      this.dataSource = new MatTableDataSource(this.subscriptionData);
    })
  }
  })

}


onChange(){
this.isAuthorized=!this.isAuthorized;
}

}
