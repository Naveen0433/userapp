import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from '../subscription';
import { SubscriptionService } from '../subscription.service';
import {FormControl} from '@angular/forms';
import {FileUploadDialogComponent} from '../file-upload-dialog/file-upload-dialog.component';

@Component({
  selector: 'app-new-subscription-dialog',
  templateUrl: './new-subscription-dialog.component.html',
  styleUrls: ['./new-subscription-dialog.component.css']
})
export class NewSubscriptionDialogComponent implements OnInit {

  isCreated: boolean;
  uploadSucess:string;
  filterListSelected=new FormControl();
 
  constructor(
  public dialog: MatDialog,
    public dialogRef: MatDialogRef<NewSubscriptionDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private subscriptionService: SubscriptionService) {
  }

  ngOnInit() {
  }

  create() {
  if(this.filterListSelected.value!=null && this.filterListSelected.value!=null){
  this.data.subscription.obligationFilter=this.filterListSelected.value;
  }
    this.subscriptionService.createSubscription(this.data.subscription).subscribe(resp => {
      this.data.subscription = resp;
      console.log(this.data.subscription);
      this.dialogRef.close(this.data.subscription);
      //this.subscriptionService.saveFile(this).subscribe(resp=>console.log(resp));
    })
  }

  cancel() {
    this.dialogRef.close();
  }

  uploadFile(): void {
    const dialogRef = this.dialog.open(FileUploadDialogComponent, {
    width:'450px',
    panelClass: 'myapp-no-padding-dialog',
      data: {}
    });

    dialogRef.afterClosed().subscribe(fileData => {
      console.log('The dialog was closed'); 
      if (fileData!={}) {
      this.uploadSucess="File Uplaoded Successfully";
      console.log(fileData.fileName);
      console.log(fileData.file);
      if(fileData.fileName==null){
        fileData.fileName=fileData.file[0].name;
      }
      this.readFile(fileData);
      }
    });
  }

  readFile(fileData:any){
  let fileReader = new FileReader();
    fileReader.onload = (e) => {
      console.log(fileReader.result);
      let result:any=fileReader.result;
      this.data.subscription.obligationFilter.push({"fileName":fileData.fileName,"file":result});
    }
    fileReader.readAsText(fileData.file[0]);
}
  
}
