import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from '../subscription';
import { SubscriptionService } from '../subscription.service';
import {FileUploadDialogComponent} from '../file-upload-dialog/file-upload-dialog.component';

@Component({
  selector: 'app-new-subscription-dialog',
  templateUrl: './new-subscription-dialog.component.html',
  styleUrls: ['./new-subscription-dialog.component.css']
})
export class NewSubscriptionDialogComponent implements OnInit {

  isCreated: boolean;
  uploadSucess:string;
  file : File;
 
  constructor(
  public dialog: MatDialog,
    public dialogRef: MatDialogRef<NewSubscriptionDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private subscriptionService: SubscriptionService) {
  }

  ngOnInit() {
  }

  create() {
    this.subscriptionService.createSubscription(this.data.subscription).subscribe(resp => {
      this.data.subscription = resp;
      console.log(this.data.subscription);
      this.dialogRef.close(this.data.subscription);
      this.subscriptionService.saveFile(this.file).subscribe(resp=>console.log(resp));
    })
  }

  cancel() {
    this.dialogRef.close();
  }

  uploadFile(): void {
    const dialogRef = this.dialog.open(FileUploadDialogComponent, {
    width:'450px',
    panelClass: 'myapp-no-padding-dialog',
      data: {}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed'); 
      if (result.length>0) {
      this.uploadSucess="File Uplaoded Successfully"
      console.log(result[0]);
      this.file=result[0];
      }
    });
  }

  
}
