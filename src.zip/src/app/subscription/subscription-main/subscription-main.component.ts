import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subscription-main',
  templateUrl: './subscription-main.component.html',
  styleUrls: ['./subscription-main.component.css']
})
export class SubscriptionMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
