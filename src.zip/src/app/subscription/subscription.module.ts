import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NewSubscriptionComponent } from './new-subscription/new-subscription.component';
import { MatDialogModule, MAT_DIALOG_DEFAULT_OPTIONS } from '@angular/material/dialog';
import { NewSubscriptionDialogComponent } from './new-subscription-dialog/new-subscription-dialog.component';
import { MatTableModule } from '@angular/material/table';
import {MatSortModule} from '@angular/material/sort';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import {MatPaginatorModule} from '@angular/material/paginator';
import { SubscriptionService } from './subscription.service';
import { SubscriptionMainComponent } from './subscription-main/subscription-main.component';
import { UpdateSubscriptionDialogComponent } from './update-subscription-dialog/update-subscription-dialog.component';
import { FileUploadDialogComponent } from './file-upload-dialog/file-upload-dialog.component';
import { ConfirmDialogComponent } from './confirm-dialog/confirm-dialog.component';
import { MatSelectModule } from '@angular/material/select';
import {MatCheckboxModule} from '@angular/material';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';

@NgModule({
  declarations: [NewSubscriptionComponent, NewSubscriptionDialogComponent, SubscriptionMainComponent, UpdateSubscriptionDialogComponent, FileUploadDialogComponent, ConfirmDialogComponent],
  entryComponents: [NewSubscriptionDialogComponent, UpdateSubscriptionDialogComponent,FileUploadDialogComponent,ConfirmDialogComponent],
  imports: [
  FormsModule,
  ReactiveFormsModule,
    CommonModule,
    MatDialogModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatSortModule,
    MatPaginatorModule,
    MatSelectModule,
    MatSlideToggleModule
  ],
  providers: [SubscriptionService,{ provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { hasBackdrop: false } }],
  exports: [NewSubscriptionComponent, NewSubscriptionDialogComponent, SubscriptionMainComponent]
})
export class SubscriptionModule { }
