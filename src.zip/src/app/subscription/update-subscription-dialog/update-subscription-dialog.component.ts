import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from '../subscription';
import { SubscriptionService } from '../subscription.service';
import {FormControl} from '@angular/forms';
import {FileUploadDialogComponent} from '../file-upload-dialog/file-upload-dialog.component';


@Component({
  selector: 'app-update-subscription-dialog',
  templateUrl: './update-subscription-dialog.component.html',
  styleUrls: ['./update-subscription-dialog.component.css']
})
export class UpdateSubscriptionDialogComponent implements OnInit {

  subscriptionOld: any;
  filterListSelected=new FormControl();
  uploadSucess:string;
  existingList:any=[];
  isEmpty:boolean;

  constructor(
    public dialog:MatDialog,
    public dialogRef: MatDialogRef<UpdateSubscriptionDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private subscriptionService: SubscriptionService) {
   this.existingList=this.data.subscription.obligationFilter;
  }

  ngOnInit() {
    
  }

  update() {
  this.isEmpty=false;
  if(this.data.subscription.filter==null || this.data.subscription.filter==''){
    this.isEmpty=true;
  }else{
  if(this.filterListSelected.value!=null && this.filterListSelected.value!=null){
  this.data.subscription.obligationFilter=this.filterListSelected.value;
  }
    this.subscriptionService.updateSubscription(this.data.subscription).subscribe(resp => {
      this.data.subscription = resp;
      console.log(this.data.subscription);
      this.dialogRef.close(this.data.subscription);
    },
      error => {
        this.dialogRef.close(this.data.oldSubscription);
      }
    )
    
   }
  }

  onChange(filterList:any){
    console.log(filterList);
  }

  cancel() {
    this.dialogRef.close(this.data.oldSubscription);
  }

    uploadFile(): void {
    const dialogRef = this.dialog.open(FileUploadDialogComponent, {
    width:'450px',
    panelClass: 'myapp-no-padding-dialog',
      data: {}
    });

    dialogRef.afterClosed().subscribe(fileData => {
      console.log('The dialog was closed');
      console.log(fileData);
      if (fileData!=undefined && fileData!={}) {
       this.uploadSucess="File Uplaoded Successfully";
      console.log(fileData.fileName);
      console.log(fileData.file);
      if(fileData.fileName==null){
        fileData.fileName=fileData.file[0].name;
      }
      this.readFile(fileData);
      }
    });
  }

    readFile(fileData:any){
  let fileReader = new FileReader();
    fileReader.onload = (e) => {
      console.log(fileReader.result);
      let result:any=fileReader.result;
      if( this.data.subscription.obligationFilter==null){
       this.data.subscription.obligationFilter=[];
      }
      this.data.subscription.obligationFilter.push({"fileName":fileData.fileName,"file":result});
    }
    fileReader.readAsText(fileData.file[0]);
}

}
