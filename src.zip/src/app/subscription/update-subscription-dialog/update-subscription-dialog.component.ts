import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from '../subscription';
import { SubscriptionService } from '../subscription.service';

@Component({
  selector: 'app-update-subscription-dialog',
  templateUrl: './update-subscription-dialog.component.html',
  styleUrls: ['./update-subscription-dialog.component.css']
})
export class UpdateSubscriptionDialogComponent implements OnInit {

  subscriptionOld: any;

  constructor(
    public dialogRef: MatDialogRef<UpdateSubscriptionDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private subscriptionService: SubscriptionService) {
  }

  ngOnInit() {
    
  }

  update() {
    this.subscriptionService.updateSubscription(this.data.subscription).subscribe(resp => {
      this.data.subscription = resp;
      console.log(this.data.subscription);
      this.dialogRef.close(this.data.subscription);
    },
      error => {
        this.dialogRef.close(this.data.oldSubscription);
      }
    )
  }

  cancel() {
    this.dialogRef.close(this.data.oldSubscription);
  }

}
