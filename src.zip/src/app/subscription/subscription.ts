export class Subscription {
  subscriptionId: number = 0;
  userOrg: string = '';
  category: string = '';
  topic: string = '';
  filter: string = '';
  obligationFilter:any=[];
  status:string='enabled';
}
