package jnet.jems2.service;

import java.util.List;

import jnet.jems2.model.Subscription;

public interface SubscriptionService {
	public Subscription save(Subscription subscription);
	public Subscription update(Subscription subscription);
	public void delete(Long subscriptionId);
	public List<Subscription> getAll();
}
