export class Subscription {
  userOrg: string = '';
  category: string = '';
  topic: string = '';
  filter: string = '';
}
