import { Component, OnInit, ViewChild, Input, OnChanges, SimpleChanges } from '@angular/core';
import {MatPaginator, MatTableDataSource} from '@angular/material';

@Component({
  selector: 'app-subscription-table',
  templateUrl: './subscription-table.component.html',
  styleUrls: ['./subscription-table.component.css']
})
export class SubscriptionTableComponent implements OnChanges{

  constructor() { }
  @Input()
  private subscriptionData: any=[];


}
