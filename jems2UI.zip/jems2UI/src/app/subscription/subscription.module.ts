import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NewSubscriptionComponent } from './new-subscription/new-subscription.component';
import { MatDialogModule, MAT_DIALOG_DEFAULT_OPTIONS } from '@angular/material/dialog';
import { NewSubscriptionDialogComponent } from './new-subscription-dialog/new-subscription-dialog.component';
import { SubscriptionTableComponent } from './subscription-table/subscription-table.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material';
import { MatFormFieldModule } from '@angular/material/form-field';
import { SubscriptionService } from './subscription.service';
import { SubscriptionMainComponent } from './subscription-main/subscription-main.component';

@NgModule({
  declarations: [NewSubscriptionComponent, NewSubscriptionDialogComponent, SubscriptionTableComponent, SubscriptionMainComponent],
  entryComponents: [NewSubscriptionDialogComponent],
  imports: [
    CommonModule,
    MatDialogModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatCardModule,
    FormsModule
  ],
  providers: [SubscriptionService,{ provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { hasBackdrop: false } }],
  exports: [NewSubscriptionComponent, NewSubscriptionDialogComponent, SubscriptionTableComponent, SubscriptionMainComponent]
})
export class SubscriptionModule { }
