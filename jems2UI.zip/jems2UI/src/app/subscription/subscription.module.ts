import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NewSubscriptionComponent } from './new-subscription/new-subscription.component';
import { MatDialogModule, MAT_DIALOG_DEFAULT_OPTIONS } from '@angular/material/dialog';
import { NewSubscriptionDialogComponent } from './new-subscription-dialog/new-subscription-dialog.component';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { SubscriptionService } from './subscription.service';
import { SubscriptionMainComponent } from './subscription-main/subscription-main.component';
import { UpdateSubscriptionDialogComponent } from './update-subscription-dialog/update-subscription-dialog.component';

@NgModule({
  declarations: [NewSubscriptionComponent, NewSubscriptionDialogComponent, SubscriptionMainComponent, UpdateSubscriptionDialogComponent],
  entryComponents: [NewSubscriptionDialogComponent, UpdateSubscriptionDialogComponent],
  imports: [
    CommonModule,
    MatDialogModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatCardModule,
    FormsModule,
    MatButtonModule
  ],
  providers: [SubscriptionService,{ provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { hasBackdrop: false } }],
  exports: [NewSubscriptionComponent, NewSubscriptionDialogComponent, SubscriptionMainComponent]
})
export class SubscriptionModule { }
