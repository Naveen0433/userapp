import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource } from '@angular/material';
import { NewSubscriptionDialogComponent } from '../new-subscription-dialog/new-subscription-dialog.component';
import { Subscription } from '../subscription';
import { SubscriptionService } from '../subscription.service';

@Component({
  selector: 'app-new-subscription',
  templateUrl: './new-subscription.component.html',
  styleUrls: ['./new-subscription.component.css']
})
export class NewSubscriptionComponent implements OnInit {

  subscription: Subscription = new Subscription();
  subscriptionData: any = [];
  data: any;
  displayedColumns: string[] = ['id', 'category', 'topic', 'agency'];
  dataSource: any;

  constructor(public dialog: MatDialog, private subscriptionService:SubscriptionService) { }

  openDialog(): void {
    const dialogRef = this.dialog.open(NewSubscriptionDialogComponent, {
      width: '250px',
      data: { subscription: this.subscription}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.subscriptionData.push(this.subscription);
      console.log(this.subscriptionData);
    });
  }

  ngOnInit() {
    this.subscriptionService.getAllSubscriptions().subscribe(
      resp => {
        this.subscriptionData = resp;
        this.dataSource = new MatTableDataSource(this.subscriptionData);
      }
    );

  }
  

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}
