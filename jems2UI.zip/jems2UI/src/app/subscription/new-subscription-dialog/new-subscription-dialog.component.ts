import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from '../subscription';
import { SubscriptionService } from '../subscription.service';

@Component({
  selector: 'app-new-subscription-dialog',
  templateUrl: './new-subscription-dialog.component.html',
  styleUrls: ['./new-subscription-dialog.component.css']
})
export class NewSubscriptionDialogComponent implements OnInit {

  subscription: any;

  constructor(
    public dialogRef: MatDialogRef<NewSubscriptionDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private subscriptionService: SubscriptionService) {
    this.subscription = data.subscription;
  }

  ngOnInit() {
  }

  create() {
    console.log(this.subscription);
    this.subscriptionService.createSubscription(this.subscription).subscribe(resp => {
      console.log(resp);
      this.subscription = resp;
    })
  }
}
