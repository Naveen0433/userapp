import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateSubscriptionDialogComponent } from './update-subscription-dialog.component';

describe('UpdateSubscriptionDialogComponent', () => {
  let component: UpdateSubscriptionDialogComponent;
  let fixture: ComponentFixture<UpdateSubscriptionDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateSubscriptionDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateSubscriptionDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
